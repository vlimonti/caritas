<?php $__env->startSection('title', "Editar equipe {$team->name}"); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Cadastros</li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('teams.index')); ?>">Equipes</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('teams.edit', $team->id)); ?>">Editar Equipe</a></li>
    </ol>
    <h1>Editar equipe <?php echo e($team->name); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('teams.update', $team->id)); ?>" class="form" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <?php echo $__env->make('admin.pages.teams._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form> 
        </div>
        <div class="card-footer">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/admin/pages/teams/edit.blade.php ENDPATH**/ ?>