<?php $__env->startSection('title', "Editar detalhe { $detail->name }"); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('plans.index')); ?>">Planos</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('plans.show', $plan->url)); ?>"><?php echo e($plan->name); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('details.plan.index', $plan->url)); ?>">Detalhes</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('details.plan.edit', [$plan->url, $detail->id])); ?>">Editar</a></li>
    </ol>

    <h1>Editar detalhe <?php echo e($detail->name); ?></h1>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('details.plan.update', [$plan->url, $detail->id])); ?>" method="post">
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('admin.pages.plans.details._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/plans/details/edit.blade.php ENDPATH**/ ?>