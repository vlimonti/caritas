<?php $__env->startSection('title', "Editar permissão {$permission->name}"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar permissão <?php echo e($permission->name); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('permissions.update', $permission->id)); ?>" class="form" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <?php echo $__env->make('admin.pages.permissions._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form> 
        </div>
        <div class="card-footer">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/admin/pages/permissions/edit.blade.php ENDPATH**/ ?>