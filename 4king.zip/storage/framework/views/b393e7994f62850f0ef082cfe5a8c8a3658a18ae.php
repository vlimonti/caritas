<?php $__env->startSection('title', "Músicas da categoria {$category->name}"); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>">Categorias</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('categories.musics', $category->id)); ?>">Músicas</a></li>
    </ol>
    <h1>Músicas da categoria <?php echo e($category->name); ?> 
        <a href="<?php echo e(route('categories.musics.available', $category->id )); ?>" class="btn btn-dark">ADD NOVA MÚSICA
            <i class="fas fa-plus"></i>
        </a>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th width=50>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $musics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $music): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($music->name); ?>

                            </td>
                            <td style="width=10px;">
                                <a href="<?php echo e(route('category.music.detach', [$category->id, $music->id])); ?>" class="btn btn-danger">Desvincular</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php if(isset($filters)): ?>
                <?php echo $musics->appends($filters)->links(); ?>

            <?php else: ?>
                <?php echo $musics->links(); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/admin/pages/categories/musics/index.blade.php ENDPATH**/ ?>