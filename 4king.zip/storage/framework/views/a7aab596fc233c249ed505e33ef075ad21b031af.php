<?php $__env->startSection('title', "Adicionar Habilidade para {$person->name } "); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Cadastro</li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('people.index')); ?>">Pessoas</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('people.skills', $person->id)); ?>">Equipes</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('people.skills.available', $person->id)); ?>">Habilidades Disponíveis</a></li>
    </ol>
    <h1>Adicionar Habilidade para <?php echo e($person->name); ?> 
    </h1>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <form action="<?php echo e(route('people.skills.available', $person->id)); ?>" method="POST" class="form form-inline">
                <?php echo csrf_field(); ?>
                <input type="text" name="filter" placeholder="Filtro" class="form-control" value="<?php echo e($filters['filter'] ?? ''); ?>">
                <button type="submit" class="btn btn-dark"><i class="fas fa-search"></i></button>
            </form>
        </div>
        <div class="card-body">
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th width="50px">#</th>
                        <th>Nome</th>
                    </tr>
                </thead>
                <tbody>
                    <form action=" <?php echo e(route('people.skills.attach', $person->id)); ?>" method="POST" class="form">
                        <?php echo csrf_field(); ?>

                        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="skills[]" value="<?php echo e($skill->id); ?>">
                                </td>
                                <td>
                                    <?php echo e($skill->name); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td colspan="500">

                                <?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <button type="submit" class="btn btn-success">Vincular</button>
                            </td>
                        </tr>
                    </form>
                    
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php if(isset($filters)): ?>
                <?php echo $skills->appends($filters)->links(); ?>

            <?php else: ?>
                <?php echo $skills->links(); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/admin/pages/people/skills/available.blade.php ENDPATH**/ ?>