<?php $__env->startSection('title', 'Cadastrar nova Música'); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('musics.index')); ?>">Músicas</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('musics.create')); ?>">Add Música</a></li>
    </ol>
    <h1>Cadastrar nova Música</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('musics.store')); ?>" class="form" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
                <?php echo $__env->make('admin.pages.musics._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form> 
        </div>
        <div class="card-footer">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/admin/pages/musics/create.blade.php ENDPATH**/ ?>