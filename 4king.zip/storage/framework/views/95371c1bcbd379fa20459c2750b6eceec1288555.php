<?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo csrf_field(); ?>

<div class="form-group">
    <label for="name">Nome</label>
    <input type="text" name="name" placeholder="Nome" class="form-control" value="<?php echo e($detail->name ?? old('name')); ?>">
</div>
<div class="form-group">
    <button type="submit" class="btn btn-success">Salvar</button>
</div><?php /**PATH C:\wamp64\www\caritas\resources\views/admin/pages/plans/details/_partials/form.blade.php ENDPATH**/ ?>