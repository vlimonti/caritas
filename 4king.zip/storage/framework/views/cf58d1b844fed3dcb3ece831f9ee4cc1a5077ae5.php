<?php $__env->startSection('title', 'Planos'); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('plans.index')); ?>">Planos</a></li>
    </ol>
    <h1>Planos <a href="<?php echo e(route('plans.create')); ?>" class="btn btn-dark">ADD <i class="fas fa-plus"></i></a></h1>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <form action="<?php echo e(route('plans.search')); ?>" method="POST" class="form form-inline">
                <?php echo csrf_field(); ?>
                <input type="text" name="filter" placeholder="Filtro" class="form-control" value="<?php echo e($filters['filter'] ?? ''); ?>">
                <button type="submit" class="btn btn-dark"><i class="fas fa-search"></i></button>
            </form>
        </div>
        <div class="card-body">
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Preço</th>
                        <th width=270>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($plan->name); ?>

                            </td>
                            <td>
                                R$ <?php echo e(number_format( $plan->price , 2, ',', '.')); ?>

                            </td>
                            <td style="width=10px;">
                                <a href="<?php echo e(route('plans.edit', $plan->url)); ?>" class="btn btn-info" title="Editar"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('plans.show', $plan->url)); ?>" class="btn btn-warning" title="Ver"><i class="fas fa-eye"></i></a>
                                <a href="<?php echo e(route('details.plan.index', $plan->url)); ?>" class="btn btn-dark" title="Detalhes"><i class="fas fa-info-circle"></i></a>
                                <a href="<?php echo e(route('plans.profiles', $plan->id)); ?>" class="btn btn-info" title="Perfis"><i class="fas fa-users"></i></a>                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php if(isset($filters)): ?>
                <?php echo $plans->appends($filters)->links(); ?>

            <?php else: ?>
                <?php echo $plans->links(); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/admin/pages/plans/index.blade.php ENDPATH**/ ?>