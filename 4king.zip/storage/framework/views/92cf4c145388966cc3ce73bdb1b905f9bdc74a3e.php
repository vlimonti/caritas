<?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="form-group">
    <label for="name">Nome:</label>
    <input type="text" name="name" class="form-control" placeholder="Nome" value="<?php echo e($category->name ?? old('name')); ?>">
</div>
<div class="form-group">
    <label for="description">Descrição:</label>
    <textarea name="description" class="form-control" ols="30" rows="5" placeholder="Descrição"><?php echo e($category->description ?? old('description')); ?></textarea>
</div>
<div class="form-group">
   <button type="submit" class="btn btn-success">Salvar</button>
</div><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/categories/_partials/form.blade.php ENDPATH**/ ?>