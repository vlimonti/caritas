<?php $__env->startSection('title', "Perfis do plano {$plan->name } "); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('plans.index')); ?>">Planos</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('plans.profiles', $plan->id)); ?>">Perfis</a></li>
    </ol>
    <h1>Perfis do plano <?php echo e($plan->name); ?> 
        <a href="<?php echo e(route('plans.profiles.available', $plan->id )); ?>" class="btn btn-dark">ADD NOVO PERFIL
            <i class="fas fa-plus"></i>
        </a>
    </h1>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th width=50>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($profile->name); ?>

                            </td>
                            <td style="width=10px;">
                                <a href="<?php echo e(route('plan.profile.detach', [$plan->id, $profile->id])); ?>" class="btn btn-danger">Desvincular</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php if(isset($filters)): ?>
                <?php echo $profiles->appends($filters)->links(); ?>

            <?php else: ?>
                <?php echo $profiles->links(); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/admin/pages/plans/profiles/index.blade.php ENDPATH**/ ?>