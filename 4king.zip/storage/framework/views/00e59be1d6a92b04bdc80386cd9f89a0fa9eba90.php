<?php $__env->startSection('title', "Detalhes da mesa { $table->identify }"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Detalhes da mesa <b><?php echo e($table->identify); ?></b></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <ul>
                <li>
                    <strong>Identificação: </strong> <?php echo e($table->identify); ?>

                </li>
                <li>
                    <strong>Descrição: </strong> <?php echo e($table->description); ?>

                </li>
            </ul>
        </div>
        <div class="card-footer">
            <?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <form action="<?php echo e(route('tables.destroy', $table->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Deletar <?php echo e($table->identify); ?></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/tables/show.blade.php ENDPATH**/ ?>