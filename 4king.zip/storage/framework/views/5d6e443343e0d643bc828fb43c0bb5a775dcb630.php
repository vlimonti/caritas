<?php $__env->startSection('title', "Editar mesa <?php echo e($table->identify); ?>"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar mesa <?php echo e($table->identify); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('tables.update', $table->id)); ?>" class="form" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <?php echo $__env->make('admin.pages.tables._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form> 
        </div>
        <div class="card-footer">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/tables/edit.blade.php ENDPATH**/ ?>