<?php $__env->startSection('title', "Adicionar novo detalhe ao plano { $plan->name }"); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('plans.index')); ?>">Planos</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('plans.show', $plan->url)); ?>"><?php echo e($plan->name); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('details.plan.index', $plan->url)); ?>">Detalhes</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('details.plan.create', $plan->url)); ?>">Novo</a></li>
    </ol>

    <h1>Adicionar novo detalhe ao plano <?php echo e($plan->name); ?></h1>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('details.plan.store', $plan->url)); ?>" method="post">
                <?php echo $__env->make('admin.pages.plans.details._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\caritas\resources\views/admin/pages/plans/details/create.blade.php ENDPATH**/ ?>