<?php $__env->startSection('title', "Detalhes da cesta {$basket->name}"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Detalhes da cesta <b><?php echo e($basket->name); ?></b></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <ul>
                <li>
                    <strong>Nome: </strong> <?php echo e($basket->name); ?>

                </li>
                <li>
                    <strong>Descrição: </strong> <?php echo e($basket->description); ?>

                </li>
            </ul>
            <hr>
            <h5> <i class="fas fa-utensils"></i> Itens da cesta:</h5>
                <ul>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($product->name); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
        </div>
        <div class="card-footer">
            <?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <form action="<?php echo e(route('baskets.destroy', $basket->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Deletar <?php echo e($basket->name); ?></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\caritas\resources\views/admin/pages/baskets/show.blade.php ENDPATH**/ ?>