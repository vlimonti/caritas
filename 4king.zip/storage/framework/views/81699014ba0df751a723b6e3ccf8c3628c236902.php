<?php $__env->startSection('title', "Detalhes do produto { $product->name }"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Detalhes do produto <b><?php echo e($product->name); ?></b></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <img src="<?php echo e(url("storage/{$product->image}")); ?>" alt="imagem ilustrativa:  <?php echo e($product->name); ?>" style="max-width:100px">
            <ul>               
                <li>
                    <strong>Nome: </strong> <?php echo e($product->name); ?>

                </li>
                <li>
                    <strong>URL: </strong> <?php echo e($product->url); ?>

                </li>
                <li>
                    <strong>Descrição: </strong> <?php echo e($product->description); ?>

                </li>
            </ul>
        </div>
        <div class="card-footer">
            <?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Deletar <?php echo e($product->name); ?></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/products/show.blade.php ENDPATH**/ ?>