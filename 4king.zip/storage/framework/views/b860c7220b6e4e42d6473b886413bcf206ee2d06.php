<?php $__env->startSection('title', "Categorias do produto {$product->name } "); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>">Produtos</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('products.categories', $product->id)); ?>">Categorias</a></li>
    </ol>
    <h1>Categorias do produto <?php echo e($product->name); ?> 
        <a href="<?php echo e(route('products.categories.available', $product->id )); ?>" class="btn btn-dark">ADD NOVA CATEGORIA
            <i class="fas fa-plus"></i>
        </a>
    </h1>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th width=50>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($category->name); ?>

                            </td>
                            <td style="width=10px;">
                                <a href="<?php echo e(route('product.category.detach', [$product->id, $category->id])); ?>" class="btn btn-danger">Desvincular</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php if(isset($filters)): ?>
                <?php echo $categories->appends($filters)->links(); ?>

            <?php else: ?>
                <?php echo $categories->links(); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/products/categories/index.blade.php ENDPATH**/ ?>