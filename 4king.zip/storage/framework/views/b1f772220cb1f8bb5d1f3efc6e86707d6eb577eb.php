<?php $__env->startSection('title', "Detalhes: {$team->name}"); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Cadastros</li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('teams.index')); ?>">Equipes</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('teams.show', $team->id)); ?>">Ver Equipe</a></li>
    </ol>
    <h1>Detalhes: <b><?php echo e($team->name); ?></b></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <ul>               
                <li>
                    <strong>Nome: </strong> <?php echo e($team->name); ?>

                </li>
                <li>
                    <strong>Responsável: </strong> <?php echo e($team->person_name); ?>

                </li>
                <li>
                    <strong>Ministério: </strong> <?php echo e($team->ministry->name); ?>

                </li>
                <li>
                    <strong>Descrição: </strong> <?php echo e($team->description); ?>

                </li>
            </ul>
        </div>
        <div class="card-footer">
            <?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <form action="<?php echo e(route('teams.destroy', $team->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Deletar <?php echo e($team->name); ?></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/admin/pages/teams/show.blade.php ENDPATH**/ ?>