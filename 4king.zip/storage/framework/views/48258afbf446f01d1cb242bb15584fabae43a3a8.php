<?php $__env->startSection('title', "Cestas disponíveis para adicionar {$product->name } "); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>">Produtos</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('products.baskets', $product->id)); ?>">Cestas</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('products.baskets.available', $product->id)); ?>">Cestas Disponíveis</a></li>
    </ol>
    <h1>Cestas disponíveis para adicionar <?php echo e($product->name); ?> 
    </h1>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <form action="<?php echo e(route('products.baskets.available', $product->id)); ?>" method="POST" class="form form-inline">
                <?php echo csrf_field(); ?>
                <input type="text" name="filter" placeholder="Filtro" class="form-control" value="<?php echo e($filters['filter'] ?? ''); ?>">
                <button type="submit" class="btn btn-dark"><i class="fas fa-search"></i></button>
            </form>
        </div>
        <div class="card-body">
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th width="50px">#</th>
                        <th>Nome</th>
                    </tr>
                </thead>
                <tbody>
                    <form action=" <?php echo e(route('products.baskets.attach', $product->id)); ?>" method="POST" class="form">
                        <?php echo csrf_field(); ?>

                        <?php $__currentLoopData = $baskets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="baskets[]" value="<?php echo e($basket->id); ?>">
                                </td>
                                <td>
                                    <?php echo e($basket->name); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td colspan="500">

                                <?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <button type="submit" class="btn btn-success">Vincular</button>
                            </td>
                        </tr>
                    </form>
                    
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php if(isset($filters)): ?>
                <?php echo $baskets->appends($filters)->links(); ?>

            <?php else: ?>
                <?php echo $baskets->links(); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\caritas\resources\views/admin/pages/products/baskets/available.blade.php ENDPATH**/ ?>