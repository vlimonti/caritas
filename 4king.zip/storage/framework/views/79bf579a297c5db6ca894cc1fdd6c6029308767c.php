<?php $__env->startSection('title', 'Cadastrar Novo Produto'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Cadastrar Novo Produto</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('products.store')); ?>" class="form" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
                <?php echo $__env->make('admin.pages.products._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form> 
        </div>
        <div class="card-footer">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/products/create.blade.php ENDPATH**/ ?>