<?php $__env->startSection('title', 'Mesas'); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('tables.index')); ?>">Mesas</a></li>
    </ol>
    <h1>Mesas <a href="<?php echo e(route('tables.create')); ?>" class="btn btn-dark">ADD <i class="fas fa-plus"></i></a></h1>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <form action="<?php echo e(route('tables.search')); ?>" method="POST" class="form form-inline">
                <?php echo csrf_field(); ?>
                <input type="text" name="filter" placeholder="Filtro" class="form-control" value="<?php echo e($filters['filter'] ?? ''); ?>">
                <button type="submit" class="btn btn-dark"><i class="fas fa-search"></i></button>
            </form>
        </div>
        <div class="card-body">
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th>Identify</th>
                        <th>Descrição</th>
                        <th width=250>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($table->identify); ?>

                            </td>
                            <td>
                                <?php echo e($table->description); ?>

                            </td>
                            <td style="width=10px;">
                                <a href="<?php echo e(route('tables.edit', $table->id)); ?>" class="btn btn-info">Edit</a>
                                <a href="<?php echo e(route('tables.show', $table->id)); ?>" class="btn btn-warning">Ver</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php if(isset($filters)): ?>
                <?php echo $tables->appends($filters)->links(); ?>

            <?php else: ?>
                <?php echo $tables->links(); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/tables/index.blade.php ENDPATH**/ ?>