<?php $__env->startSection('title', "Detalhes da função {$role->name}"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Detalhes da função <b><?php echo e($role->name); ?></b></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <ul>
                <li>
                    <strong>Nome: </strong> <?php echo e($role->name); ?>

                </li>
                <li>
                    <strong>Descrição: </strong> <?php echo e($role->description); ?>

                </li>
            </ul>
        </div>
        <div class="card-footer">
            <?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Deletar função <?php echo e($role->name); ?></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/admin/pages/roles/show.blade.php ENDPATH**/ ?>