<?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="form-group">
    <label for="name">Nome:</label>
    <input type="text" name="name" class="form-control" placeholder="Nome" value="<?php echo e($user->name ?? old('name')); ?>">
</div>
<div class="form-group">
    <label for="email">Email:</label>
    <input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo e($user->email ?? old('email')); ?>">
</div>
<div class="form-group">
    <label for="password">Senha:</label>
    <input type="password" name="password" class="form-control" placeholder="Senha">
</div>
<div class="form-group">
   <button type="submit" class="btn btn-success">Salvar</button>
</div><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/users/_partials/form.blade.php ENDPATH**/ ?>