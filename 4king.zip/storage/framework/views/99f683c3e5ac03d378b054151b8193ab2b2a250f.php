<?php $__env->startSection('title', 'Equipes'); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Cadastros</li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('teams.index')); ?>">Equipes</a></li>
    </ol>
    <h1>Equipes <a href="<?php echo e(route('teams.create')); ?>" class="btn btn-dark">ADD <i class="fas fa-plus"></i></a></h1>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <form action="<?php echo e(route('teams.search')); ?>" method="POST" class="form form-inline">
                <?php echo csrf_field(); ?>
                <input type="text" name="filter" placeholder="Filtro" class="form-control" value="<?php echo e($filters['filter'] ?? ''); ?>">
                <button type="submit" class="btn btn-dark"><i class="fas fa-search"></i></button>
            </form>
        </div>
        <div class="card-body">
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Responsável</th>
                        <th>Ministério</th>
                        <th width=250>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($team->name); ?>

                            </td>
                            <td>
                                <?php echo e($team->person_name); ?>

                            </td>
                            <td>
                                <?php echo e($team->ministry->name); ?>

                            </td>
                            <td style="width=10px;">
                                <a href="<?php echo e(route('teams.edit', $team->id)); ?>" class="btn btn-info" title="Editar"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('teams.show', $team->id)); ?>" class="btn btn-warning" title="Ver"><i class="fas fa-eye"></i></a>
                                <a href="<?php echo e(route('teams.people', $team->id)); ?>" class="btn btn-info" title="Pessoas da Equipe"><i class="fas fa-user"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php if(isset($filters)): ?>
                <?php echo $teams->appends($filters)->links(); ?>

            <?php else: ?>
                <?php echo $teams->links(); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/admin/pages/teams/index.blade.php ENDPATH**/ ?>