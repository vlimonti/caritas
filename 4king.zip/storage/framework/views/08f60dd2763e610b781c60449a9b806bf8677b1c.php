<?php $__env->startSection('title', 'Cadastrar Nova Função'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Cadastrar Nova Função </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('roles.store')); ?>" class="form" method="post">
                <?php echo csrf_field(); ?>
                
                <?php echo $__env->make('admin.pages.roles._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form> 
        </div>
        <div class="card-footer">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\caritas\resources\views/admin/pages/roles/create.blade.php ENDPATH**/ ?>