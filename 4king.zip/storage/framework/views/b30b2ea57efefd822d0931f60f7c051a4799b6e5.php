<?php $__env->startSection('title', "Produtos da cesta {$basket->name}"); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('baskets.index')); ?>">Cestas</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('baskets.products', $basket->id)); ?>">Produtos</a></li>
    </ol>
    <h1>Produtos da cesta <?php echo e($basket->name); ?> 
        <a href="<?php echo e(route('baskets.products.available', $basket->id )); ?>" class="btn btn-dark">ADD NOVO PRODUTO
            <i class="fas fa-plus"></i>
        </a>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th width=50>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($product->name); ?>

                            </td>
                            <td style="width=10px;">
                                <a href="<?php echo e(route('basket.product.detach', [$basket->id, $product->id])); ?>" class="btn btn-danger">Desvincular</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php if(isset($filters)): ?>
                <?php echo $products->appends($filters)->links(); ?>

            <?php else: ?>
                <?php echo $products->links(); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\caritas\resources\views/admin/pages/baskets/products/index.blade.php ENDPATH**/ ?>