<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1 class="title-plan">About</h1>
    </div>
    <div class="row">
        <h1>About</h1>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/site/pages/about/index.blade.php ENDPATH**/ ?>