<?php $__env->startSection('title', 'Cadastrar Novo Plano'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Cadastrar Novo Plano </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('plans.store')); ?>" class="form" method="post">
                <?php echo csrf_field(); ?>
                
                <?php echo $__env->make('admin.pages.plans._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form> 
        </div>
        <div class="card-footer">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/plans/create.blade.php ENDPATH**/ ?>