<?php $__env->startSection('title', "Detalhes da empresa {$tenant->name}"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Detalhes da empresa <b><?php echo e($tenant->name); ?></b></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <img src="<?php echo e(url("storage/{$tenant->logo}")); ?>" alt="logo:  <?php echo e($tenant->name); ?>" style="max-width:100px">
            <ul>
                <li>
                    <strong>Plano: </strong> <?php echo e($tenant->plan->name); ?>

                </li>
                <li>
                    <strong>Nome: </strong> <?php echo e($tenant->name); ?>

                </li>
                <li>
                    <strong>URL: </strong> <?php echo e($tenant->url); ?>

                </li>
                <li>
                    <strong>Email: </strong> <?php echo e($tenant->email); ?>

                </li>
                <li>
                    <strong>CNPJ: </strong> <?php echo e($tenant->cnpj); ?>

                </li>
                <li>
                    <strong>Ativo: </strong> <?php echo e($tenant->active == 'Y' ? 'SIM' : 'NÃO'); ?>

                </li>
            </ul>
            <h3>Assinatura</h3>
            <ul>
                <li>
                    <strong>Data assinatura: </strong> <?php echo e($tenant->subscription); ?>

                </li>
                <li>
                    <strong>Data Expira: </strong> <?php echo e($tenant->expires_at); ?>

                </li>
                <li>
                    <strong>Identificador: </strong> <?php echo e($tenant->subscription_id); ?>

                </li>
                <li>
                    <strong>Ativo: </strong> <?php echo e($tenant->subscription_active == 'Y' ? 'SIM' : 'NÃO'); ?>

                </li>
                <li>
                    <strong>Cancelou? </strong> <?php echo e($tenant->subscription_suspended == 'Y' ? 'SIM' : 'NÃO'); ?>

                </li>
            </ul>
        </div>
        <div class="card-footer">
            <?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\caritas\resources\views/admin/pages/tenants/show.blade.php ENDPATH**/ ?>