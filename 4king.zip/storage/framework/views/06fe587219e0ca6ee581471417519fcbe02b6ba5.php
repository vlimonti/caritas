<?php $__env->startSection('title', "Equipes da pessoa"); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Cadastro</li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('people.index')); ?>">Pessoas</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('people.teams', $person->id)); ?>">Equipes</a></li>
    </ol>
    <h1>Equipes da pessoa
        <a href="<?php echo e(route('people.teams.available', $person->id )); ?>" class="btn btn-dark">ADD NOVA EQUIPE
            <i class="fas fa-plus"></i>
        </a>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th width=50>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($team->name); ?>

                            </td>
                            <td style="width=10px;">
                                <a href="<?php echo e(route('person.team.detach', [$person->id, $team->id])); ?>" class="btn btn-danger">Desvincular</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php if(isset($filters)): ?>
                <?php echo $teams->appends($filters)->links(); ?>

            <?php else: ?>
                <?php echo $teams->links(); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\4king\resources\views/admin/pages/people/teams/index.blade.php ENDPATH**/ ?>