<?php $__env->startSection('title', "Detalhes do perfil { $profile->name }"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Detalhes do perfil <b><?php echo e($profile->name); ?></b></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <ul>
                <li>
                    <strong>Nome: </strong> <?php echo e($profile->name); ?>

                </li>
                <li>
                    <strong>Descrição: </strong> <?php echo e($profile->description); ?>

                </li>
            </ul>
        </div>
        <div class="card-footer">
            <?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <form action="<?php echo e(route('profiles.destroy', $profile->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Deletar perfil <?php echo e($profile->name); ?></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/profiles/show.blade.php ENDPATH**/ ?>