<?php $__env->startSection('title', "Detalhes do detalhe { $detail->name }"); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('plans.index')); ?>">Planos</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('plans.show', $plan->url)); ?>"><?php echo e($plan->name); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('details.plan.index', $plan->url)); ?>">Detalhes</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('details.plan.show', [$plan->url, $detail->id])); ?>">Detalhes do detalhe</a></li>
    </ol>

    <h1>Detalhes do detalhe <?php echo e($detail->name); ?></h1>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <ul>
                <li>
                    <strong>Nome: </strong> <?php echo e($detail->name); ?>

                </li>
            </ul>
        </div>
        <div class="card-footer">
            <form action="<?php echo e(route('details.plan.destroy', [ $plan->url, $detail->id ])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Deletar detalhe</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\larafood\resources\views/admin/pages/plans/details/show.blade.php ENDPATH**/ ?>