@extends('site.layouts.app')

@section('content')
    <div class="text-center">
        <h1 class="title-plan">About</h1>
    </div>
    <div class="row">
        <h1>About</h1>
    </div>
@endsection