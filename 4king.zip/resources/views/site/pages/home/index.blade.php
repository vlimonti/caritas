@extends('site.layouts.app')

@section('content')
    <div class="text-center">
        <h1 class="title-plan">Bem vindo!</h1>
    </div>
    <div class="row">
        <h1>BEM VINDO!</h1>
    </div>
@endsection