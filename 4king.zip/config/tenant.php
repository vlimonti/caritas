<?php

return [
    /**
     * Admin e-mails
    */
    'admins' => [
        'admin@4king.com.br',
    ],
];